# ***************************************************************************
# Copyright (c) 2016 SAP SE or an SAP affiliate company. All rights reserved.
# ***************************************************************************
These examples are intended to be used with the SAP HANA node.js driver.
