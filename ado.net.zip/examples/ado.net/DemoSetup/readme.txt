# ***************************************************************************
# Copyright (c) 2014 SAP AG or an SAP affiliate company. All rights reserved.
# ***************************************************************************

Use the project contained within this folder to set up the demo tables, views,
and procedures used in the documentation and the tutorial examples.

Use the Connect button to connect to an SAP HANA server. You must fill in an
appropriate connection string first.


Use the Create demo objects button to create the demo tables, views, and
procedures.

Use the Remove demo objects button to remove the demo tables, views, and
procedures.

Use the Disconnect button to disconnect from the server.

This project demonstrates a number of features of the SAP HANA .NET Data 
Provider.

