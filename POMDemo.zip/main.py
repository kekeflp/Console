import unittest
import sys
from unittest import runner
from common import HTMLTestRunnerCN
from testcase.testSearchPage import TestSearchPage

if __name__ == '__main__':
    test_suite = unittest.TestSuite()
    test_suite.addTest(TestSearchPage('testSearch'))

    # 在当前目录, 输出测试报告
    htmlPath = u"page_demo_Report.html"
    fp = open(htmlPath, 'wb')
    runner = HTMLTestRunnerCN.HTMLTestReportCN(stream=fp,
                                               title=u"百度测试",
                                               description=u"测试用例结果")
    runner.run(test_suite)
    fp.close()
