from selenium.webdriver.common.by import By
from pages.basePage import Page


class SearchPage(Page):
    search_input = (By.ID, u"kw")
    search_button = (By.ID, u"su")

    # 类似构造函数
    def __init__(self, driver, base_url):
        Page.__init__(self, driver, base_url)

    def gotoBaiduHomePage(self):
        print(u"打开首页", self.base_url)
        self.driver.get(self.base_url)

    def input_search_text(self, text):
        print(u"输入搜索关键字: selenium")
        self.input_text(self.search_input, text)

    def click_search_btn(self):
        print(u"点击 百度一下 按钮")
        self.click(self.search_button)
