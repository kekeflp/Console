class Page(object):
    """
        Page基类, 所有page都应该继承该类
    """
    def __init__(self, driver, base_url):
        self.driver = driver
        self.base_url = base_url
        self.timeout = 30

    def find_element(self, *arg):
        return self.driver.find_element(*arg)

    def input_text(self, arg, text):
        self.find_element(*arg).send_keys(text)

    def click(self, arg):
        self.find_element(*arg).click()

    def get_title(self):
        return self.driver.title